﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UI.Extensions.ColorPicker;

namespace EContent_Task
{
    /// <summary>
    /// Handles UI states and button OnClick methods
    /// </summary>
    public class UIController : MonoBehaviour
    {
        public DrawTrail drawTrail;
        public RectTransform settingsPanelRect;
        public RectTransform editScreenshotPanelRect;
        public RectTransform screenshotImageRect;
        public RectTransform colorPickerRect;
        public Text saveInfoText;

        /// <summary>
        /// Set default state of UI before start of the application
        /// </summary>
        private void Awake()
        {
            settingsPanelRect.gameObject.SetActive(true);
            editScreenshotPanelRect.gameObject.SetActive(false);
            screenshotImageRect.gameObject.SetActive(false);
            colorPickerRect.gameObject.SetActive(false);
            saveInfoText.rectTransform.parent.gameObject.SetActive(false);
            drawTrail.CanDraw = false;
        }

        /// <summary>
        /// OnClick() method for Screenshot button
        /// </summary>
        public void OnScreenshotButton()
        {
            settingsPanelRect.gameObject.SetActive(false);
            editScreenshotPanelRect.gameObject.SetActive(true);
            screenshotImageRect.gameObject.SetActive(true);
            colorPickerRect.gameObject.SetActive(false);
            drawTrail.CanDraw = true;
        }

        /// <summary>
        /// OnClick() method for opening brush color picker
        /// </summary>
        public void OnBrushColorButton()
        {
            colorPickerRect.GetComponent<ColorPickerControl>().CurrentColor = drawTrail.BrushColor;
            colorPickerRect.gameObject.SetActive(true);
            drawTrail.CanDraw = false;
        }

        /// <summary>
        /// OnClick() method for applying new brush color
        /// </summary>
        public void OnBrushColorApplyButton()
        {
            Color newColor = colorPickerRect.GetComponent<ColorPickerControl>().CurrentColor;
            drawTrail.BrushColor = newColor;
            colorPickerRect.gameObject.SetActive(false);
            drawTrail.CanDraw = true;
        }

        /// <summary>
        /// OnClick() method for canceling change of brush color
        /// </summary>
        public void OnBrushColorCancelButton()
        {
            colorPickerRect.gameObject.SetActive(false);
            drawTrail.CanDraw = true;
        }

        /// <summary>
        /// OnClick() method for button canceling edit of a screenshot
        /// </summary>
        public void OnCancelButton()
        {
            settingsPanelRect.gameObject.SetActive(true);
            editScreenshotPanelRect.gameObject.SetActive(false);
            screenshotImageRect.gameObject.SetActive(false);
            colorPickerRect.gameObject.SetActive(false);
            saveInfoText.rectTransform.parent.gameObject.SetActive(false);
            drawTrail.CanDraw = false;
            foreach (Transform child in screenshotImageRect)
            {
                Destroy(child.gameObject);
            }
        }

        /// <summary>
        /// Method to hide/show UI for action of taking screenshot
        /// </summary>
        public void ChangeStateUIForScreenshot(bool enabled)
        {
            //GetComponent<Canvas>().enabled = enabled;
            settingsPanelRect.gameObject.SetActive(false);
            editScreenshotPanelRect.gameObject.SetActive(enabled);
            colorPickerRect.gameObject.SetActive(false);
            saveInfoText.rectTransform.parent.gameObject.SetActive(false);
        }

        /// <summary>
        /// Method showing message about saved screenshot
        /// </summary>
        /// <param name="savePath">Path of saved screenshot</param>
        /// <returns></returns>
        public IEnumerator OnSaveScreenshot(string savePath)
        {
            saveInfoText.text = "Screen saved: " + savePath;
            saveInfoText.rectTransform.parent.gameObject.SetActive(true);
            yield return new WaitForSeconds(3f);
            saveInfoText.rectTransform.parent.gameObject.SetActive(false);
        }
    }
}
