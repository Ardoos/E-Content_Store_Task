﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI.Extensions;

namespace EContent_Task
{
    /// <summary>
    /// Handles drawing system
    /// </summary>
    public class DrawTrail : MonoBehaviour
    {
        public CameraController cameraController;
        public GameObject linePrefab;
        public RectTransform canvasRect;
        public RectTransform screenshotImage;
        public bool CanDraw
        {
            get { return canDraw; }
            set
            {
                canDraw = value;
                OnDrawStateChange(value);
                cameraController.isActive = !value;
            }
        }
        private bool canDraw;

        public Color BrushColor { set { brushColor = value; } get { return brushColor; } }
        private Color brushColor;

        GameObject curLine;
        public List<GameObject> lineRenderers;

        /// <summary>
        /// Initialize variables at the start
        /// </summary>
        private void Awake()
        {
            CanDraw = false;
            lineRenderers = new List<GameObject>();
            BrushColor = Color.white;
        }

        /// <summary>
        /// Checks for draw input every frame
        /// </summary>
        void Update()
        {
            if (CanDraw)
            {
                DrawingLineRenderer();
            }
        }

        /// <summary>
        /// Dependent on touch phase creates new line or modifies it
        /// </summary>
        private void DrawingLineRenderer()
        {
            if (Input.GetMouseButtonDown(0) || (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began))
            {
                curLine = (GameObject)Instantiate(linePrefab, Vector3.zero, Quaternion.identity, screenshotImage);
                curLine.GetComponent<UILineRenderer>().color = BrushColor;
                curLine.GetComponent<RectTransform>().localPosition = Vector3.zero;

                AddNewPoint();
            }
            else if ((Input.GetMouseButton(0) || (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Moved)) && curLine != null)
            {
                AddNewPoint();
            }
            else if ((Input.GetMouseButtonUp(0) || (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Ended)) && curLine != null)
            {
                AddNewPoint();
                EndDrawing();
            }
        }

        /// <summary>
        /// Handles end of touch phase. If line has just one point (e.g. click without move) deletes it
        /// </summary>
        void EndDrawing()
        {
            if (curLine.GetComponent<UILineRenderer>().Points.Length <= 1)
                Destroy(curLine);
            else
                lineRenderers.Add(curLine);
            curLine = null;
        }

        /// <summary>
        /// Modifies points of created line
        /// </summary>
        void AddNewPoint()
        {
            Vector2 touchPosition = Input.mousePosition;
#if UNITY_ANDROID && !UNITY_EDITOR
        touchPosition = Input.GetTouch(0).position; //Input.mousePosition return avarage of touch positions and we want to have position of first touch
#endif

            Vector2 canvasPos = ConvertMousePositionToCanvas(touchPosition);
            UILineRenderer lineRenderer = curLine.GetComponent<UILineRenderer>();
            if (lineRenderer.Points.Length > 0 && lineRenderer.Points[lineRenderer.Points.Length - 1] == canvasPos)
                return;
            var pointsList = new List<Vector2>(lineRenderer.Points);
            pointsList.Add(canvasPos);
            lineRenderer.Points = pointsList.ToArray();
        }

        /// <summary>
        /// Converts input to canvas position in order to put line points in correct position
        /// </summary>
        /// <remarks>
        /// Point (0, 0) for mouse input is in left down corner, for canvas it's in the middle of the screen
        /// </remarks>
        /// <param name="mousePosition">Vector2 coordinates of mouse position</param>
        /// <returns>Vector2 line position in canvas for given mouse position</returns>
        Vector2 ConvertMousePositionToCanvas(Vector2 mousePosition)
        {
            Vector2 screenSize = new Vector2(Screen.width, Screen.height);
            Vector2 mouseClickPercentage = (mousePosition - screenSize / 2f) / new Vector2(Screen.width, Screen.height);
            Vector2 canvasPos = mouseClickPercentage * new Vector2(canvasRect.rect.width, canvasRect.rect.height);
            return canvasPos;
        }

        /// <summary>
        /// Undo last drawn line. Can be repeated multiple times
        /// </summary>
        public void UndoLastDraw()
        {
            if (lineRenderers.Count > 0)
            {
                int idToRemove = lineRenderers.Count - 1;
                Destroy(lineRenderers[idToRemove]);
                lineRenderers.RemoveAt(idToRemove);
            }
        }

        /// <summary>
        /// When drawing is being disabled ends modyfing current line
        /// </summary>
        /// <param name="newState">New state of drawing possibility</param>
        private void OnDrawStateChange(bool newState)
        {
            if (!newState && curLine != null)
            {
                AddNewPoint();
                EndDrawing();
            }
        }
    }
}