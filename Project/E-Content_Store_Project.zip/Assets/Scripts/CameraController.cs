﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace EContent_Task
{
    /// <summary>
    /// Controls camera rotation with touch
    /// </summary>
    public class CameraController : MonoBehaviour
    {
        public bool isActive;

        Vector3 FirstPoint;
        Vector3 SecondPoint;
        float xAngle;
        float yAngle;
        float xAngleTemp;
        float yAngleTemp;

        /// <summary>
        /// Initialization of variables
        /// </summary>
        void Start()
        {
            xAngle = 0;
            yAngle = 0;
            this.transform.rotation = Quaternion.Euler(yAngle, xAngle, 0);
            isActive = true;
        }

        /// <summary>
        /// Looking for input every frame and rotating camera according to it
        /// </summary>
        void Update()
        {
            if (isActive)
            {
                if (Input.GetMouseButtonDown(0) || (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began))
                {
                    FirstPoint = Input.mousePosition;
#if UNITY_ANDROID && !UNITY_EDITOR
            FirstPoint = Input.GetTouch(0).position;
#endif
                    xAngleTemp = xAngle;
                    yAngleTemp = yAngle;
                }
                else if (Input.GetMouseButton(0) || (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Moved))
                {
                    SecondPoint = Input.mousePosition;
#if UNITY_ANDROID && !UNITY_EDITOR
            SecondPoint = Input.GetTouch(0).position;
#endif
                    xAngle = xAngleTemp + (SecondPoint.x - FirstPoint.x) * 180 / Screen.width;
                    yAngle = yAngleTemp + (SecondPoint.y - FirstPoint.y) * 90 / Screen.height;
                    this.transform.rotation = Quaternion.Euler(yAngle, xAngle, 0.0f);
                }
            }
        }
    }
}
