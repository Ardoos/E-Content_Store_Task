﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

namespace EContent_Task
{
    /// <summary>
    /// Class responsible for taking screenshots
    /// </summary>
    public class ScreenshotController : MonoBehaviour
    {
        public Image targetImage;
        public UIController uIController;

        /// <summary>
        /// Method exposed to add as OnClick() for taking screenshot button
        /// </summary>
        public void OnScreenshotButton()
        {
            StartCoroutine(TakeScreenshot());
        }

        /// <summary>
        /// Method exposed to add as OnClick() for saving edited screenshot button
        /// </summary>
        public void OnSaveScreenshotButton()
        {
            StartCoroutine(SaveScreenshot());
        }

        /// <summary>
        /// Coroutine for taking screenshot to edit. Uses coroutine in order to hide UI before taking screenshot,
        /// waits until end of frame and shows screenshot on UI Image object, enabling UI again
        /// </summary>
        /// <returns>IEnumerator, necessary to wait until end of the frame</returns>
        public IEnumerator TakeScreenshot()
        {
            uIController.ChangeStateUIForScreenshot(false);
            yield return new WaitForEndOfFrame();
            Texture2D texture = ScreenCapture.CaptureScreenshotAsTexture();
            uIController.ChangeStateUIForScreenshot(true);

            targetImage.sprite = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), new Vector2(0.5f, 0.5f));
            targetImage.gameObject.SetActive(true);
            uIController.OnScreenshotButton();
        }

        /// <summary>
        /// Coroutine for saving edited screenshot. Uses coroutine in order to hide UI before saving final screenshot,
        /// waits until end of frame and saves screenshot in persistent data path of the device
        /// </summary>
        /// <returns>IEnumerator, necessary to wait until end of the frame</returns>
        public IEnumerator SaveScreenshot()
        {
            string screenshotName = "screen_" + System.DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss");
            uIController.ChangeStateUIForScreenshot(false);
            yield return new WaitForEndOfFrame();
            string savePath = Application.persistentDataPath + "/" + screenshotName + ".png";
            ScreenCapture.CaptureScreenshot(savePath);
            uIController.ChangeStateUIForScreenshot(true);
            StartCoroutine(uIController.OnSaveScreenshot(savePath));
        }
    }
}
